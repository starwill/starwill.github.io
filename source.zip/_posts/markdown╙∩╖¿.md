---
title:  markdown语法
date: 2016-12-26
tags: markdown
catetories: GitHub
---
### 标题  
![](http://oi63esxp7.bkt.clouddn.com/1.jpg)
<!--more-->
### 列表  
 ![](http://oi63esxp7.bkt.clouddn.com/ni.jpg)
### 引用
使用尖括号>
![](http://oi63esxp7.bkt.clouddn.com/3.jpg)
### 图片与链接
区别在于是否有感叹号
![](http://oi63esxp7.bkt.clouddn.com/4.jpg)
### 粗体与斜体
用两个 * 包含的是粗体用法，也就是(&lowast;&lowast;)  

**这里是粗体**   *这里是斜体*  
### 代码框  
![](http://oi63esxp7.bkt.clouddn.com/7.PNG)  
或者直接用 ``将代码区域包含起来即可  

![](http://oi63esxp7.bkt.clouddn.com/5.jpg)

### 表格  
直接输入table会跳出如下  
![](http://oi63esxp7.bkt.clouddn.com/8.PNG)  
显示如下：  

| Header One     | Header Two     |
| :------------- | :------------- |
| Item One       | Item Two       |
