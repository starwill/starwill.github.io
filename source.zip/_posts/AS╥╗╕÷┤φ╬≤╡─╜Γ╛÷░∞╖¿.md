---
title: AS一个错误的解决办法
date: 2017-03-01 13:52:39
catetories: [Debug]
tags: [Android_Studio,Debug,Error]
---
最近开始项目实训，正踌躇满志的时候给我来个一天也没解决的bug，项目中没有报错，可是不管clean还是rebuild都无法找回丢失的R文件，错误如下：
```
Error:Execution failed for task ':app:mergeDebugResources'.
> Error: java.util.concurrent.ExecutionException: com.android.ide.common.process.ProcessException:
```    

这里不说废话，解决方法如下：在app的.gradle中加入下面这两句话：  
![](http://oi63esxp7.bkt.clouddn.com/QQ%E5%9B%BE%E7%89%8720170301140411.png)  
百度了一下这两句话主要作用是关闭.png图片的合法性检查，想了下遇到过两次这种错误的确导入过别人的drawable资源。。
