---
title: JavaWeb学习笔记（一）
date: 2017-1-23
tags: [JavaWeb]
catetories: JavaWeb
---
# 一.HTML基础  
## 常用标签
### 1.文本控制标签  
`<p></p>`  ：段落  
`<br/>`：（break row）换行  
`<hr/>`：创建水平线  
`<h1></h1>~<h6></h6>`：标题  
### 2.表格相关标签  
`<table></table>`：常用属性有两个  
**align**（对齐，取值为left、center、right）  
**border**（表格边框大小，取值为数字，如border="1"）
<!--more--> 
