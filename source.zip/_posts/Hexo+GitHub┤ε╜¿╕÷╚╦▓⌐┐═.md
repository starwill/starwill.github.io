---
title: Hexo+GitHub个人博客的搭建及使用
date: 2017-1-21
tags: [GitHub,Hexo]
catetories: GitHub
---


### 什么是Hexo？
[hexo](https://hexo.io/)是一款基于Node.js的静态博客框架。不过我用起来更像是一个在Git上发布博客的工具。目前在GitHub上已有14043 star 和 2191 fork  
###  那么，什么又是Node.js?
在这篇文章里又关于Node.js的详细叙述[Node.js究竟是什么？](http://www.ibm.com/developerworks/cn/opensource/os-nodejs/)，不过对于还没入门的来说比较深奥，我个人理解就是JavaScript的运行环境了。  
<!--more-->
### 什么是GitHub Page？
[GitHub Page](https://github.com/blog/272-github-pages)官方文档的介绍有这么一段话：  
`If you create a repository named you.github.com, where you is your username, and push content to it, we’ll automatically publish that to http://you.github.com. No FTP, no scp, no rsync, nothing. Just a simple git push and you’re done. You can put anything here you like. Use it as a customizable home for your Git repos. Create a blog and spread your ideas. Whatever you want!`  
那么我认为GitHub Page就是一个特殊容器，该容器的内容会自动显示在 http：//you.github.com 上。  
### 搭建一个GitHub+Hexo博客过程
首先推荐这个博客[简洁轻便的博客平台: Hexo详解](http://www.tuicool.com/articles/ueI7naV)，特详细，我这个只是自我总结
1. 第一步自然是安装Node.js。这里直接官网下载安装就好。
2. `npm install -g hexo-cli`//全局安装hexo
3. `hexo init <folder>`  
`npm install`  
//会在当前目录创建一个folder并且在此初始化hexo，关于初始化后的目录结构以及功能在官方文档[hexo](https://hexo.io/docs/setup.html)里都有介绍，我觉得需要耐下心来观看
4. 安装插件(这几个插件不是很懂)：  
`npm install npm install hexo-deployer-git --save`//hexo d部署到git插件  
`npm install hexo-generator-feed --save`  //RSS订阅插件  
`npm install hexo-generator-sitemap --save` //站点地图插件
5. `hexo server`//这时候可以启动hexo服务器查看运行效果，不过得切换到hexo得安装目录下运行。  

ps：将hexo迁移到其他电脑上的过程和搭建的过程类似，不过因为是将hexo文件夹复制到新电脑，所以忽略`hexo init <folder>`这个命令就好。
### 主题基本设置
首先要在hexo的安装目录下更改_config.yml全局配置文件，需要更改的属性不多。示例如下：
```
title: 阿星的博客
subtitle:
description:
author: Starwill
language: zh-Hans
timezone: Asia/Shanghai

theme: hexo-theme-next//这里配置使用主题

deploy:
  type: git
  repo: git@github.com:starwill/starwill.github.io.git
  branch: master
```
其次就是选择主题了，官方主题给的是landscape，不过为了体现GitHub自定义博客与其他博客的不同（装个XX），大部分人还是选择一些民间大神自定义的主题。这里推荐两款主题：[fexo](https://github.com/forsigner/fexo)和[NexT](https://github.com/iissnan/hexo-theme-next)，NexT主题是使用人数最多的，这个配置只需要严格按照官方文档设置就行 [next使用文档](http://theme-next.iissnan.com/).(注：千万不要瞎删东西，不过删了也可以通过git找回)

### 初步使用！！！！
这个狂想吐槽！！！！（当你deploy过后有的链接如分类关于这样的点开后显示404，那么，并不是主题部署出错啊啊啊！为这个我换了NNN个主题！！）  
hexo的目录基本使用只需要看scaffolds（模板目录）、source（资源目录，存放文章和分类标签之类的文件夹）。  

首先需要建立About、Categories、tags页面
```
hexo new page "about"
hexo new page "catetories"
hexo new page "tags"
```
这样source文件夹下就有了三个about、catetories、tags命名的文件夹以及各自的index页面。当然最后还要在主题配置文件里面的menu一下添加url如下：
```
menu:
  home: /
  categories: /categories
  about: /about
  archives: /archives
  tags: /tags
```
然后下面关于写文章就比较简单了。  
创建一篇文章，
`hexo new [layout] "title"`这里的layout是scaffolds文件夹下的三个模板，省略的话就会自动选择post模板，为了方便博客的编写，我们可以将模板改成下面这种形式：
```---
title: {{ title }}
date: {{ date }}  
catetories:
tags: [GitHub,Hexo]
---```  
注意如果tags有多个的话需要加[]。显示一部分内容需要在分割线下加<!--more-->。
