---
title: Git学习笔记
date: 2017-1-16
tags: [GitHub,Git]
catetories: GitHub
---

### Git安装配置
windows下安装直接下载[Git](https://www.git-scm.com/download/win)可执行文件，然后一键式安装就好。装好之后需要为你的机器设置一下名字和地址  
` git config --global user.name "starwill"`  
` git config --global user.email "email address"`  
查看配置项：` git config -l`
<!--more-->
### 创建版本库以及添加文件（repository）
1. 创建一个空目录即可  
2. cd进入该目录，通过`git init`即可变成仓库，目录下会多出`.git`文件夹，关于文件夹的作用可在  [.git文件夹详解](http://blog.csdn.net/u010331406/article/details/49128607)详细了解
3. 关于添加文件，首先要新建或者更改一个已有文件。（只能跟踪文本文件，二进制文件无法跟踪。）然后通过一下命令：  
`git add readme.txt`//将添加或者修改文件提交的暂存区  
`git rm filename`//将删除操作提交到暂存区  
`git commit -m "illustration"`//将暂存区文件或操作提交到分支中，并说明   
`git status`//查看当前状态  
`git diff readme.txt`//查看修改的具体内容（只有在工作区和分支中文件不同时才会显示）
4. 运行原理  
将工作区文件修改一个个添加（add）到暂存区（stage）中，然后将暂存区中的内容一次性提交到分支中（master）
![](http://oi63esxp7.bkt.clouddn.com/QQ%E6%88%AA%E5%9B%BE20170116204102.png)

### 版本控制
* `git log`//查看每次提交的历史，用于历史的回退
* `git reflog`//查看命令的历史，用于找回未来版本
* `git reset --hard head`//**head** 表示当前当前版本 **head^** 表示上一个版本 **head~100** 表示前100个版本 也可以直接加文件名
* `git checkout -- readme.txt`//丢弃工作区修改，也就是用版本库覆盖工作区的操作

### 分支命令
分支的作用在于你不用一直在master分支上工作，确保你开发的代码不会影响到别人观看。    
有关的分支命令：  
查看分支：`git branch`  
创建分支:`git branch <name>`  
切换分支：`git checkout`  
创建+切换分支：`git checkout -b <name>`  
合并某分支到当前分支(master)：`git merge <name>`  
删除分支：`git branch -d <name>`  

### 远程仓库
1. ###### 生成ssh key免密登录  
`ssh-keygen -t rsa -C "youremail@.."`//在gitbash中输入该命令，会在user/yourusername/.ssh 文件夹下生成 **id_rsa** 和 **id_rsa.pub** 两个文件，然后将pub文件copy到github中的SSH KEY中。  
2. ###### 将本地分支与远程分支关联起来
在GitHub上创建一个同名的版本库  
`git remote add origin git/github.com:starwill/test.git`//将本地仓库与远程仓库关联起来  
`git push -u origin master`//将本地内容推送到远程，第一次推送需要加`-u`，用于将本地master分支和远程master分支关联起来，以后的每次推送可以去掉。
`git clone git/github.com:starwill/starwill.github.io`//将远程仓库clone到本地仓库
